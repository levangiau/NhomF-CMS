<?php get_header();
get_template_part('content/2','content');
get_template_part('content/3','content');
get_template_part('content/4','content');
get_template_part('content/5','content');
get_footer();
?>