<?php 
/*
Template Name: services
*/
get_header();
get_template_part('content/10','content');
get_footer();
?>