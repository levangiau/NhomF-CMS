
<?php 
get_template_part('content/6','content');
wp_footer();?>
</body>
</html>