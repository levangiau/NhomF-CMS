<!DOCTYPE html>
<html>
<head>
	<title>Document</title>
</head>
<?php wp_head();?>
<body>
<?php get_template_part('content/1','content');?>