<?php 
/*
Template Name: Abouts
*/
get_header();
get_template_part('content/7','content');
get_template_part('content/8','content');
get_footer();
?>