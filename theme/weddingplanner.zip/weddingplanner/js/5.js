
$(document).ready(function(){
	var swiper = new Swiper('.swiper-container', {
		slidesPerView: 4,
		spaceBetween: 30,
		
	});
	//click show img
	// $('i').click(function(){
	// 	$('.a').fadeIn({'display': 'block'});

	// });
	//   $('.remove').click(function(){
	//   	$('.show_img').fadeOut('slow');
  // });

});