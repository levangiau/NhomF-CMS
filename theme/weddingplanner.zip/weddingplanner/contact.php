<?php
/*
 Template Name: Contact
 
 */
get_header();
get_template_part('content/9','content');
get_footer();
 ?>